require 'aka/configuration.pb'
require "aka/shortcut"
require "aka/shortcut_manager"
require "aka/link_manager"
require "aka/upgrader"
require "aka/store"
require "aka/version"
require "aka/app"

module Aka
end
